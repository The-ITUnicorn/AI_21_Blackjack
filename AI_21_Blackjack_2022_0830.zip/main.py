from blackjack import *


pygame.init()

Running = True
while Running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            Running = False


    table.playintro()
    table.musicscreen()
    if table.music:
        playlist = []
        for song in os.listdir('music'):
            playlist.append(os.path.join('music', song))
        print('music is true')
        mixer.init()
        for track in playlist:
            mixer.music.load(track)
            mixer.music.play(-1)
    table.howmanyplayersscreen()
    table.createplayers()
    table.simulationscreen()
    table.strategyscreen()

    table.shuffle()

    while len(table.players) > 1:
        table.playhand()

