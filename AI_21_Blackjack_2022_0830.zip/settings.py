import pygame
import os
import time
#from PIL import Image
import random
from pygame import movie
from pygame import mixer
from pyvidplayer import Video
#import moviepy.editor as mp

gamespeed = 10

display_width = 800
display_height = 700

gameDisplay = pygame.display.set_mode((display_width,display_height))
pygame.display.set_caption('BlackJackSimulator by Damien The IT-Unicorn')

font_name = pygame.font.match_font('arial')
def text_objects(text, font, textColor):
    textSurface = font.render(text, True, textColor)
    return textSurface, textSurface.get_rect()

simulation = False

minbet = 5


#############
##COLORS#####
#############
black = (0,0,0)
white = (255,255,255)
felt = (76,153,0)
red = (200,0,0)
green = (0,200,0)
bright_red = (255,0,0)
bright_green = (0,255,0)
blue = (0,0,255)
grey = (169,169,169)

################
##IMAGES########
################
img_2C = pygame.image.load('img/cards/2C.jpg')
img_3C = pygame.image.load('img/cards/3C.jpg')
img_4C = pygame.image.load('img/cards/4C.jpg')
img_5C = pygame.image.load('img/cards/5C.jpg')
img_6C = pygame.image.load('img/cards/6C.jpg')
img_7C = pygame.image.load('img/cards/7C.jpg')
img_8C = pygame.image.load('img/cards/8C.jpg')
img_9C = pygame.image.load('img/cards/9C.jpg')
img_10C = pygame.image.load('img/cards/10C.jpg')
img_JC = pygame.image.load('img/cards/JC.jpg')
img_QC = pygame.image.load('img/cards/QC.jpg')
img_KC = pygame.image.load('img/cards/KC.jpg')
img_AC = pygame.image.load('img/cards/AC.jpg')
img_2S = pygame.image.load('img/cards/2S.jpg')
img_3S = pygame.image.load('img/cards/3S.jpg')
img_4S = pygame.image.load('img/cards/4S.jpg')
img_5S = pygame.image.load('img/cards/5S.jpg')
img_6S = pygame.image.load('img/cards/6S.jpg')
img_7S = pygame.image.load('img/cards/7S.jpg')
img_8S = pygame.image.load('img/cards/8S.jpg')
img_9S = pygame.image.load('img/cards/9S.jpg')
img_10S = pygame.image.load('img/cards/10S.jpg')
img_JS = pygame.image.load('img/cards/JS.jpg')
img_QS = pygame.image.load('img/cards/QS.jpg')
img_KS = pygame.image.load('img/cards/KS.jpg')
img_AS = pygame.image.load('img/cards/AS.jpg')
img_2D = pygame.image.load('img/cards/2D.jpg')
img_3D = pygame.image.load('img/cards/3D.jpg')
img_4D = pygame.image.load('img/cards/4D.jpg')
img_5D = pygame.image.load('img/cards/5D.jpg')
img_6D = pygame.image.load('img/cards/6D.jpg')
img_7D = pygame.image.load('img/cards/7D.jpg')
img_8D = pygame.image.load('img/cards/8D.jpg')
img_9D = pygame.image.load('img/cards/9D.jpg')
img_10D = pygame.image.load('img/cards/10D.jpg')
img_JD = pygame.image.load('img/cards/JD.jpg')
img_QD = pygame.image.load('img/cards/QD.jpg')
img_KD = pygame.image.load('img/cards/KD.jpg')
img_AD = pygame.image.load('img/cards/AD.jpg')
img_2H = pygame.image.load('img/cards/2H.jpg')
img_3H = pygame.image.load('img/cards/3H.jpg')
img_4H = pygame.image.load('img/cards/4H.jpg')
img_5H = pygame.image.load('img/cards/5H.jpg')
img_6H = pygame.image.load('img/cards/6H.jpg')
img_7H = pygame.image.load('img/cards/7H.jpg')
img_8H = pygame.image.load('img/cards/8H.jpg')
img_9H = pygame.image.load('img/cards/9H.jpg')
img_10H = pygame.image.load('img/cards/10H.jpg')
img_JH = pygame.image.load('img/cards/JH.jpg')
img_QH = pygame.image.load('img/cards/QH.jpg')
img_KH = pygame.image.load('img/cards/KH.jpg')
img_AH = pygame.image.load('img/cards/AH.jpg')
img_cardback = pygame.image.load('img/cards/cardback.jpg')