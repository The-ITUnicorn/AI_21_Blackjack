from settings import *



class Button:
    def __init__(self, left, top, length, width, textstr, value):
        self.top = top
        self.left = left
        self.length = length
        self.width = width
        self.textstr = textstr
        self.value = value

    def print(self):
        pygame.draw.rect(gameDisplay, grey, (self.left, self.top, self.length, self.width))
        font = pygame.font.SysFont(None, 24)
        img = font.render(self.textstr, True, black)
        gameDisplay.blit(img, (self.left + 20, self.top + 20))


class Hand():
    def __init__(self):
        self.cards = []
        self.total = 0
        self.cardcoordx = 20
        self.cardcoordy = 30
        self.blackjack = False
        self.double = False
        self.split = False
        self.bet = 0
        self.action = 2


class Player():
    def __init__(self):
        self.stack = 2000
        self.name = 'Player'
        self.runningcount = 0
        self.remainingdecks = 0
        self.bestmove = ''
        self.hands = []
        self.currenthand = 0
        self.hands.append(Hand())
        self.betsize = 0
        self.betStrategy = "MIT Strategy"
        self.reveal = False
        self.insurance = 0


    def clearname(self):
        pygame.draw.rect(gameDisplay, black, pygame.Rect(self.hands[0].cardcoordx - 20, self.hands[0].cardcoordy - 27, display_width / 2 - 100, 25), 0)
        pygame.display.flip()


    def showname(self):
        self.clearname()
        if self.hands[self.currenthand].total > 21:
            self.recalc()
        text = self.name + '  $' + str(round(self.stack, 1)) + ' : ' + str(self.hands[self.currenthand].total) + ' : Bet: $' + str(round(self.hands[self.currenthand].bet, 1))
        largeText = pygame.font.Font('freesansbold.ttf', 20)
        TextSurf, TextRect = text_objects(text, largeText, grey)
        TextRect.center = (self.hands[0].cardcoordx + 140, self.hands[0].cardcoordy - 15)
        gameDisplay.blit(TextSurf, TextRect)
        pygame.display.flip()


    def shownamedealer(self):
        self.clearname()
        if self.hands[self.currenthand].total > 21:
            self.recalc()
        if self.hands[self.currenthand].cards[1].img == img_cardback:
            text = self.name + ' : showing ' + self.hands[self.currenthand].cards[0].number
        else:
            text = self.name + ' : ' + str(self.hands[self.currenthand].total)
        largeText = pygame.font.Font('freesansbold.ttf', 20)
        TextSurf, TextRect = text_objects(text, largeText, grey)
        TextRect.center = (self.hands[self.currenthand].cardcoordx + 100, self.hands[self.currenthand].cardcoordy - 15)
        gameDisplay.blit(TextSurf, TextRect)
        pygame.display.flip()


    def placeBet(self):
        if simulation:
            if self.betsize > self.stack:
                while self.betsize > self.stack:
                    self.betsize -= minbet
            if self.betsize == 0:
                self.betsize = minbet
            self.stack -= self.betsize
            self.hands[self.currenthand].bet = self.betsize

    def surrender(self):
        print('player has surrendered')
        self.stack += (self.hands[self.currenthand].bet / 2)
        self.hands.pop(self.currenthand)

    def buyinsurance(self):
        self.insurance = self.hands[0].bet / 2

    def win(self):
        print('running win function')
        print('current hand is ' + str(self.currenthand))
        print('bet for current hand is ' + str(self.hands[self.currenthand].bet))
        self.stack += (self.hands[self.currenthand].bet * 2)


    def winblackjack(self):
        self.stack += (self.hands[self.currenthand].bet * 2)
        self.stack += self.hands[self.currenthand].bet * .5


    def push(self):
        self.stack += self.hands[self.currenthand].bet


    def hit(self):

        self.hands[self.currenthand].cards.append(table.shoe[0])
        if self.hands[self.currenthand].cards[len(self.hands[self.currenthand].cards) - 1].number == 'A':
            self.hands[self.currenthand].cards[len(self.hands[self.currenthand].cards) - 1].value = 11
        self.hands[self.currenthand].total += self.hands[self.currenthand].cards[len(self.hands[self.currenthand].cards) - 1].value
        if self.hands[self.currenthand].total > 21:
            self.recalc()

        #adjust running count for cards dealt in hit function
        if table.shoe[0].value > 1 and table.shoe[0].value < 7:
            table.runningcount += 1
        elif table.shoe[0].value == 10 or table.shoe[0].value == 11 or table.shoe[0].value == 1:
            table.runningcount -= 1

        table.shoe.pop(0)
        handlen = len(self.hands[self.currenthand].cards)
        self.hands[self.currenthand].cards[handlen - 1].displayCard(self.hands[self.currenthand].cardcoordx + (20 * (handlen - 1)), self.hands[self.currenthand].cardcoordy)
        table.showcountinfo()

        if self.name == 'Dealer':
            self.shownamedealer()
        else:
            self.showname()
        pygame.display.flip()
        time.sleep(1 / gamespeed)

    def recalc(self):

            for card in self.hands[self.currenthand].cards:
                if self.hands[self.currenthand].total > 21:
                    self.hands[self.currenthand].total = 0
                    if card.value == 11:
                        card.value = 1
                    for card in self.hands[self.currenthand].cards:
                        self.hands[self.currenthand].total += card.value


class Card():
    def __init__(self, number, suit):
        self.number = number
        self.suit = suit
        if self.number == 'J' or self.number == 'Q' or self.number == 'K':
            self.value = 10
        elif self.number  == 'A':
            self.value = 11
        else:
            self.value = int(self.number)

        self.img = pygame.image.load('img/cards/' + self.number + self.suit[0].upper() + '.jpg')
        self.frontimg = self.img



    def displayCard(self, x, y):

        gameDisplay.blit(self.img, (x,y))
        pygame.display.flip()
        time.sleep(1 / gamespeed)




class Deck():
    def __init__(self):
        self.cards = []
        suits = ['spades','diamonds','hearts','clubs']
        nums = ['2','3','4','5','6','7','8','9','10','J','Q','K','A']
        for suit in suits:
            for num in nums:
                card = Card(num, suit)
                self.cards.append(card)


class Table:
    def __init__(self):
        self.startingdecks = 0
        self.remainingdecks = 0
        self.runningcount = 0
        self.truecount = 0
        self.playeradvantage = (self.truecount - 1) / 2
        self.betStrategy = "MIT Strategy"
        self.minbet = 5
        self.betamount = self.minbet
        self.betunit = self.minbet * 5
        self.buttonarray = []
        self.decks = []
        self.deckcount = 6
        self.players = []
        self.shoe = []
        self.bestmove = ''
        self.numberofplayers = 0
        self.music = False
        self.handcount = 0

    def createplayers(self):
        for x in range(self.numberofplayers):
            x = Player()
            self.players.append(x)
            x.table = table

        x = 0
        dealer = len(self.players) - 1
        while x < len(self.players) - 1:
            if x <= 2:
                self.players[x].hands[self.players[x].currenthand].cardcoordy = display_height - (170 + x*180)
                self.players[x].hands[self.players[x].currenthand].cardcoordx = 20
                self.players[x].name = 'Player'+str(x+1)
            elif x > 2:
                self.players[x].hands[self.players[x].currenthand].cardcoordy = self.players[x-3].hands[self.players[x-1].currenthand].cardcoordy
                self.players[x].hands[self.players[x].currenthand].cardcoordx = display_width/2
                self.players[x].name = 'Player' + str(x + 1)
            x += 1
        self.players[dealer].hands[self.players[dealer].currenthand].cardcoordy = 50
        self.players[x].hands[self.players[x].currenthand].cardcoordx = 20
        self.players[dealer].name = 'Dealer'


    def shuffle(self):
        self.decks = []
        self.shoe = []
        for i in range(self.deckcount):
            self.decks.append(Deck())
        for deck in self.decks:
            random.shuffle(deck.cards)
            for card in deck.cards:
                self.shoe.append(card)
        print('shoe populated with ' + str(len(self.shoe)) + ' cards.')
        random.shuffle(self.shoe)
        self.runningcount = 0
        self.truecount = 0


    def showhandcount(self):
        self.handcount += 1
        text = 'Hand #: ' + str(self.handcount)
        largeText = pygame.font.Font('freesansbold.ttf', 20)
        TextSurf, TextRect = text_objects(text, largeText, grey)
        TextRect.center = (display_width/2, 20)
        gameDisplay.blit(TextSurf, TextRect)
        pygame.display.flip()


    def clearcountinfo(self):
        pygame.draw.rect(gameDisplay, black, pygame.Rect(display_width * 2/3, 0, display_width / 2 - 100, 80), 0)
        pygame.display.flip()


    def showcountinfo(self):

        self.clearcountinfo()

        largeText = pygame.font.Font('freesansbold.ttf', 20)
        TextSurf, TextRect = text_objects('Running Count: ' + str(self.runningcount), largeText, grey)
        TextRect.center = (display_width - 120, 20)
        gameDisplay.blit(TextSurf, TextRect)

        if self.remainingdecks != 0:
            largeText = pygame.font.Font('freesansbold.ttf', 20)
            TextSurf, TextRect = text_objects('True Count: ' + str(round(self.runningcount / self.remainingdecks, 2)),
                                              largeText, grey)
            TextRect.center = (display_width - 120, 45)
            gameDisplay.blit(TextSurf, TextRect)

        largeText = pygame.font.Font('freesansbold.ttf', 20)
        cardstilshuffle = len(self.shoe) - 50
        if cardstilshuffle < 0:
            cardstilshuffle = 0
        TextSurf, TextRect = text_objects('Cards Until Shuffle: ' + str(cardstilshuffle), largeText, grey)
        TextRect.center = (display_width - 140, 70)
        gameDisplay.blit(TextSurf, TextRect)


    def deal(self):
        gameDisplay.fill(black)

        self.showhandcount()

        self.showcountinfo()

        dealer = self.players[len(self.players) - 1]

        for player in self.players:

            player.hands[player.currenthand].cards.append(self.shoe[0])
            if player.hands[0].cards[0].number == 'A':
                player.hands[0].cards[0].value = 11

            player.hands[player.currenthand].total += player.hands[0].cards[0].value
            if self.shoe[0].value > 1 and self.shoe[0].value < 7:
                self.runningcount +=1
            elif self.shoe[0].value == 10 or self.shoe[0].value == 11 or self.shoe[0].value == 1:
                self.runningcount -= 1
            self.shoe.pop(0)
            player.hands[player.currenthand].cards[0].displayCard(player.hands[0].cardcoordx, player.hands[0].cardcoordy)
            self.showcountinfo()

            player.hands[player.currenthand].cards.append(self.shoe[0])
            if player.hands[0].cards[1].number == 'A':
                player.hands[0].cards[1].value = 11
            player.hands[player.currenthand].total += player.hands[0].cards[1].value
            if self.shoe[0].value > 1 and self.shoe[0].value < 7:
                self.runningcount +=1
            elif self.shoe[0].value == 10 or self.shoe[0].value == 11 or self.shoe[0].value ==1:
                self.runningcount -= 1
            self.shoe.pop(0)
            if player == dealer:
                dealer.hands[0].cards[1].img = img_cardback
            player.hands[player.currenthand].cards[1].displayCard(player.hands[0].cardcoordx + 20, player.hands[0].cardcoordy)
            self.showcountinfo()

            if player == dealer:
                player.shownamedealer()
            else:
                player.showname()

            if player.hands[player.currenthand].total == 22:
                player.recalc()
            if player.hands[player.currenthand].total == 21:
                player.hands[player.currenthand].blackjack = True

        self.remainingdecks = len(self.shoe) / 52

        for player in self.players:

            #in simulation mode, we auto buy insurance if the count is correct
            if dealer.hands[0].cards[0].number == 'A':
                if self.truecount >= 3:
                    player.buyinsurance()

            if dealer.hands[0].blackjack == True and player.insurance > 0:
                player.stack += player.insurance * 2
                print(player.name + ' wins insurance')
                player.insurance = 0




    def clearhands(self):
        for player in self.players:
            player.insurance = 0
            if len(player.hands) > 1:
                h = len(player.hands) - 1
                while h > 0:
                    player.hands.pop(h)
                    h -= 1

            for hand in player.hands:
                hand.total = 0
                hand.cards.clear()
                hand.blackjack = False
                hand.split = False
                hand.double = False

            player.currenthand = 0


    def bettingRound(self):

        self.calculateBestBet()

        if simulation:
            x = 0
            while x < len(self.players) - 1:
                self.players[x].placeBet()
                x += 1


    def actionRound(self):
        if simulation:
            x = 0
            while x < len(self.players) - 1:

                Running = True
                while Running:
                    if self.players[len(self.players) - 1].hands[0].blackjack == False:

                        player = self.players[x]
                        self.bestaction(player)

                        if player.bestmove == 'surrender':
                            player.surrender()
                            print('player has surrendered')
                            Running = False

                        #if aces are split, you can only hit one time
                        if len(player.hands[player.currenthand].cards) == 1:
                            if player.hands[player.currenthand].cards[0].number == 'A':
                                player.hands[player.currenthand].cards[0].value = 11
                                player.hit()
                                player.bestmove = 'stand'

                            else:
                                player.hands[player.currenthand].total = player.hands[player.currenthand].cards[0].value
                                player.bestmove = 'hit'

                        if player.hands[player.currenthand].total >= 21 or player.bestmove == 'stand':
                            Running = False

                        if player.bestmove == 'double':
                            if player.stack >= player.hands[player.currenthand].bet:
                                player.stack -= player.hands[player.currenthand].bet
                                player.hands[player.currenthand].bet += player.hands[player.currenthand].bet
                                player.hit()
                                Running = False
                            else:
                                player.bestmove = 'hit'

                        if player.bestmove == 'hit':
                            player.hit()

                        if player.bestmove == 'split':
                            print(player.name + ' is splitting')

                            player.hands.append(Hand()) #create new hand for split
                            player.hands[len(player.hands) -1].bet = player.hands[len(player.hands) -2].bet  #add bet to new hand
                            player.stack -= player.hands[len(player.hands) -1].bet #subtract the additional hands bet from the players stack
                            player.hands[len(player.hands) - 1].cards.append(player.hands[player.currenthand].cards[1])  #add spit card to new hand
                            player.hands[player.currenthand].total -= player.hands[player.currenthand].cards[1].value  #subtract split card from og hand total
                            player.hands[player.currenthand].cards.pop(1)  #remove split card from og hand

                            #adjust card coordinates depending on how many hands player now has following split
                            player.hands[len(player.hands) -1].cards[0].displayCard(player.hands[0].cardcoordx, player.hands[0].cardcoordy + (20 * (len(player.hands) -1)))

                    else:
                        print('dealer has blackjack, exiting actionround function')
                        Running = False

                player = self.players[x]
                if player.currenthand == len(player.hands) - 1 or len(player.hands) == 0:
                    x += 1
                else:
                    player.currenthand += 1
                    player.hands[player.currenthand].cardcoordx = player.hands[player.currenthand - 1].cardcoordx
                    player.hands[player.currenthand].cardcoordy = player.hands[player.currenthand - 1].cardcoordy + 20

            dealer = self.players[len(self.players) - 1]
            dealer.hands[0].cards[1].img = dealer.hands[0].cards[1].frontimg

            dealer.hands[dealer.currenthand].cards[1].displayCard(dealer.hands[0].cardcoordx + 20, dealer.hands[0].cardcoordy)
            dealer.shownamedealer()
            while dealer.hands[0].total < 17:
                dealer.hit()


    def playhand(self):

        Running = True
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                Running = False

        if len(self.shoe) < 50:
            self.shuffle()

        self.clearhands()

        self.bettingRound()

        self.deal()

        time.sleep(1)

        self.actionRound()

        time.sleep(1 / gamespeed)

        self.evaluatehand()

        time.sleep(1 / gamespeed)


    def evaluatehand(self):

        print('starting evaluate hand function')
        x = 0
        dealer = len(self.players) - 1
        for x in range(len(self.players) - 1):

            if self.players[dealer].hands[0].blackjack == True and self.players[x].hands[0].blackjack == False:
                print('dealer has blackjack, player does not, player loses')

            else:
                self.players[x].currenthand = 0
                for hand in self.players[x].hands:
                    if hand.total <= 21:

                        if hand.blackjack == True and self.players[dealer].hands[0].blackjack == True:
                            self.players[x].push()
                            print('player' + str(x) + ' has blackjack but pushes')

                        elif hand.blackjack == True and self.players[dealer].hands[0].blackjack == False:
                            self.players[x].winblackjack()
                            print('player ' + str(x) + 'wins with blackjack')

                        elif hand.total < 22 and self.players[dealer].hands[0].total > 21:
                            self.players[x].win()
                            print('player ' + str(x) + 'wins, dealer busts')

                        elif hand.total == self.players[dealer].hands[0].total:
                            self.players[x].push()
                            print('player ' + str(x) + 'pushes')

                        elif hand.total > self.players[dealer].hands[0].total:
                            self.players[x].win()
                            print('player ' + str(x) + 'wins')
                        else:
                            print('player ' + str(x) + 'loses')
                    else:
                        print('player ' + str(x) + 'busted')

            self.players[x].currenthand += 1


    def calculateBestBet(self):

        for player in self.players:

            if self.betStrategy == "MIT Strategy":
                if self.remainingdecks != 0:
                    if (self.runningcount / self.remainingdecks) < 2:
                        player.betsize = minbet
                    else:
                        player.betsize = (int(self.runningcount / self.remainingdecks) -1)* (minbet * 5)

            if self.betStrategy == "Blackjack Trainer Strategy":
                if self.remainingdecks != 0:
                    if (self.runningcount / self.remainingdecks) < 1:
                        player.betsize = minbet
                    else:
                        player.betsize = (int(self.runningcount / self.remainingdecks) + 1) * (minbet)


    def bestaction(self, player):
        print('starting best action function')
        dealerlen = len(self.players) - 1
        dealer = self.players[dealerlen]

        #WEHN TO BUY SURRENDER
        if len(player.hands) == 1:
            if len(player.hands[0].cards) == 2:
                if player.hands[0].total == 16:
                    if dealer.hands[0].cards[0].value == 8:
                        if self.truecount >= 4:
                            player.bestmove = 'surrender'
                    if dealer.hands[0].cards[0].value == 9:
                        if self.truecount <= -1:
                            player.bestmove = 'surrender'
                    if dealer.hands[0].cards[0].value == 10 or dealer.hands[0].cards[0].number == 'A':
                        player.bestmove = 'surrender'

                if player.hands[0].total == 15:
                    if dealer.hands[0].cards[0].value == 9:
                        if self.truecount >= 2:
                            player.bestmove = 'surrender'
                    if dealer.hands[0].cards[0].value == 10:
                        if self.truecount <= 0:
                            player.bestmove = 'surrender'
                    if dealer.hands[0].cards[0].number == 'A':
                        if self.truecount >= 2:
                            player.bestmove = 'surrender'

        #https://www.blackjackapprenticeship.com/blackjack-strategy-charts/
        #WHEN TO SPLIT
        if len(player.hands[player.currenthand].cards) == 2:
            print(player.name + ' has only two cards')
            if player.hands[player.currenthand].cards[0].value == 2 and player.hands[player.currenthand].cards[1].value == 2:
                if dealer.hands[0].cards[0].value > 3 and dealer.hands[0].cards[1].value < 8:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) < 4:
                            self.bestmove = 'split'
            if player.hands[player.currenthand].cards[0].value == 3 and player.hands[player.currenthand].cards[1].value == 3:
                if dealer.hands[0].cards[0].value > 3 and dealer.hands[0].cards[1].value < 8:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) < 4:
                            self.bestmove = 'split'
            if player.hands[player.currenthand].cards[0].value == 6 and player.hands[player.currenthand].cards[1].value == 6:
                if dealer.hands[0].cards[0].value > 2 and dealer.hands[0].cards[1].value < 7:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) < 4:
                            self.bestmove = 'split'
            if player.hands[player.currenthand].cards[0].value == 7 and player.hands[player.currenthand].cards[1].value == 7:
                if dealer.hands[0].cards[0].value > 1 and dealer.hands[0].cards[1].value < 8:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) < 4:
                            self.bestmove = 'split'
            if player.hands[player.currenthand].cards[0].value == 8 and player.hands[player.currenthand].cards[1].value == 8:
                if player.stack >= player.hands[player.currenthand].bet:
                    if len(player.hands) < 4:
                        self.bestmove = 'split'
            if player.hands[player.currenthand].cards[0].value == 9 and player.hands[player.currenthand].cards[1].value == 9:
                if player.stack >= player.hands[player.currenthand].bet:
                    if dealer.hands[0].cards[0].value != 1 and dealer.hands[0].cards[1].value != 7 and dealer.hands[0].cards[1].value < 10:
                        if len(player.hands) < 4:
                            self.bestmove = 'split'

            if (player.hands[player.currenthand].cards[0].value == 11 or player.hands[player.currenthand].cards[0].value == 1) and (player.hands[player.currenthand].cards[1].value == 11 or player.hands[player.currenthand].cards[1].value == 1):
                if player.stack >= player.hands[player.currenthand].bet:
                    if len(player.hands) < 4:
                        self.bestmove = 'split'

            #Play deviation - when to split tens
            if player.hands[player.currenthand].cards[0].value == 10 and player.hands[player.currenthand].cards[1].value == 10:
                if dealer.hands[0].cards[0].value == 4:
                    if table.truecount >= 6:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) < 4:
                                self.bestmove = 'split'

            #Play deviation - when to split tens
            if player.hands[player.currenthand].cards[0].value == 10 and player.hands[player.currenthand].cards[1].value == 10:
                if dealer.hands[0].cards[0].value == 5:
                    if table.truecount >= 5:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) < 4:
                                self.bestmove = 'split'

            #Play deviation - when to split tens
            if player.hands[player.currenthand].cards[0].value == 10 and player.hands[player.currenthand].cards[1].value == 10:
                if dealer.hands[0].cards[0].value == 6:
                    if table.truecount >= 4:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) < 4:
                                self.bestmove = 'split'




        #SOFT COUNT PLAYS
        softace = False
        for card in player.hands[player.currenthand].cards:
            if card.value == 11:
                softace = True
        if softace == True:
            print(player.name + ' soft ace is true')
            if player.hands[player.currenthand].total == 13 or player.hands[player.currenthand].total == 14:
                print(player.name + ' soft ace 13 total')
                if dealer.hands[0].cards[0].value > 4 and dealer.hands[0].cards[1].value < 7:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'
                else:
                    self.bestmove = 'hit'

            if player.hands[player.currenthand].total == 15 or player.hands[player.currenthand].total == 16:
                print(player.name + ' soft ace 15 or 16 total')
                if dealer.hands[0].cards[0].value > 3 and dealer.hands[0].cards[1].value < 7:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'
                    else:
                        self.bestmove = 'hit'
                else:
                    self.bestmove = 'hit'

            if player.hands[player.currenthand].total == 17:
                print(player.name + ' soft ace 17 total')
                
                #deviation play
                if dealer.hands[0].cards[0].value == 2:
                    if table.truecount >= 1:
                        if len(player.hands[player.currenthand].cards) == 2:
                            self.bestmove = 'double'
                    else:
                        self.bestmove = 'hit'
                if dealer.hands[0].cards[0].value > 2 and dealer.hands[0].cards[1].value < 7:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'
                    else:
                        self.bestmove = 'hit'
                if dealer.hands[0].cards[0].value > 6 or dealer.hands[0].cards[1].value == 1:
                    self.bestmove = 'hit'

            if player.hands[player.currenthand].total == 18:
                print(player.name + ' soft ace 18 total')
                if dealer.hands[0].cards[0].value == 1 or dealer.hands[0].cards[0].value > 8:
                    self.bestmove = 'hit'
                if dealer.hands[0].cards[0].value == 7 or dealer.hands[0].cards[0].value == 8:
                    self.bestmove = 'stand'
                if dealer.hands[0].cards[0].value > 1 and dealer.hands[0].cards[0].value < 7:
                    if len(player.hands[player.currenthand].cards) == 2:
                        player.bestmove = 'double'
                    else:
                        player.bestmove = 'stand'

            #deviation play
            if player.hands[player.currenthand].total == 19:
                print(player.name + ' soft ace 19 total')
                if dealer.hands[0].cards[0].value == 6:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                if table.truecount >= 0:
                                    self.bestmove = 'double'
                #deviation play
                if dealer.hands[0].cards[0].value == 5:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                if table.truecount >= 1:
                                    self.bestmove = 'double'
                #deviation play
                if dealer.hands[0].cards[0].value == 4:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                if table.truecount >= 3:
                                    self.bestmove = 'double'

                else:
                    self.bestmove = 'stand'



            if player.hands[player.currenthand].total == 20:
                print(player.name + ' soft ace 20  total')
                self.bestmove = 'stand'

            if player.hands[player.currenthand].total == 21:
                print(player.name + ' soft ace 21  total')
                self.bestmove = 'stand'


        #HARD COUNT PLAYS

        elif player.hands[player.currenthand].total < 8:
            print(player.name + ' hard count < 8')
            self.bestmove = 'hit'

        #deviation play
        elif player.hands[player.currenthand].total == 8:
            if dealer.hands[0].cards[0].value == 6:
                if table.truecount >= 2:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'
                else:
                    self.bestmove = 'hit'

        # deviation play
        elif player.hands[player.currenthand].total == 9:
            print(player.name + ' hard count  9')
            if dealer.hands[0].cards[0].value == 2:
                if table.truecount >= 1:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'
            # deviation play
            if dealer.hands[0].cards[0].value == 7:
                if table.truecount >= 3:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'


            if dealer.hands[0].cards[0].value > 2 and dealer.hands[0].cards[1].value < 7:
                if len(player.hands[player.currenthand].cards) == 2:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) == 1:
                            self.bestmove = 'double'
            else:
                self.bestmove = 'hit'


        elif player.hands[player.currenthand].total == 10:
            print(player.name + ' hard count  10')
            if dealer.hands[0].cards[0].value > 1 and dealer.hands[0].cards[0].value < 10:
                if len(player.hands[player.currenthand].cards) == 2:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) == 1:
                            self.bestmove = 'double'

            #deviation play
            if dealer.hands[0].cards[0].value == 1 or dealer.hands[0].cards[0].value > 9:
                if len(player.hands[player.currenthand].cards) == 2:
                    if table.truecount >= 4:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'

            else:
                self.bestmove = 'hit'



        elif player.hands[player.currenthand].total == 11:
            print(player.name + ' hard count  11')
            if dealer.hands[0].cards[0].value > 1 and dealer.hands[0].cards[0].value < 11:
                if len(player.hands[player.currenthand].cards) == 2:
                    if player.stack >= player.hands[player.currenthand].bet:
                        if len(player.hands) == 1:
                            self.bestmove = 'double'

            #deviation play
            if dealer.hands[0].cards[0].value == 1 or dealer.hands[0].cards[0].value == 1:
                if table.truecount >= 1:
                    if len(player.hands[player.currenthand].cards) == 2:
                        if player.stack >= player.hands[player.currenthand].bet:
                            if len(player.hands) == 1:
                                self.bestmove = 'double'

            else:
                self.bestmove = 'hit'


        elif player.hands[player.currenthand].total == 12:
            print(player.name + ' hard count  12')
            #deviation play
            if dealer.hands[0].cards[0].value == 2:
                if table.truecount >= 3:
                    self.bestmove = 'stand'
            #deviation play
            if dealer.hands[0].cards[0].value == 3:
                if table.truecount >= 2:
                    self.bestmove = 'stand'
            #deviation play
            if dealer.hands[0].cards[0].value == 4:
                if table.truecount <= 0:
                    self.bestmove = 'stand'

            elif dealer.hands[0].cards[0].value > 3 and dealer.hands[0].cards[1].value < 7:
                self.bestmove = 'stand'
            else:
                self.bestmove = 'hit'

        #deviation play
        if player.hands[player.currenthand].total == 13:
            if dealer.hands[0].cards[0].value == 2:
                if table.truecount <= -1:
                    self.bestmove = 'hit'

        #deviation play
        if player.hands[player.currenthand].total == 15:
            if dealer.hands[0].cards[0].value == 10:
                if table.truecount >= 4:
                    self.bestmove = 'stand'

        #deviation play
        if player.hands[player.currenthand].total == 16:
            if dealer.hands[0].cards[0].value == 9:
                if table.truecount >= 4:
                    self.bestmove = 'stand'

        #deviation play
        if player.hands[player.currenthand].total == 16:
            if dealer.hands[0].cards[0].value == 10:
                if table.truecount >= 0:
                    self.bestmove = 'stand'

        elif player.hands[player.currenthand].total > 12 and player.hands[player.currenthand].total < 17:
            print(player.name + ' hard count 13 - 16')
            if dealer.hands[0].cards[0].value >= 2 and dealer.hands[0].cards[1].value < 7:
                self.bestmove = 'stand'
            else:
                self.bestmove = 'hit'

        elif player.hands[player.currenthand].total >= 17:
            print(player.name + ' hard count  17 or higher')
            self.bestmove = 'stand'

        player.bestmove = self.bestmove


    def getbestaction(self):
        for player in self.players:
            self.bestaction(player)


    def howmanyplayersscreen(self):

        gameDisplay.fill(black)

        largeText = pygame.font.Font('freesansbold.ttf', 50)
        TextSurf, TextRect = text_objects('How Many Players?', largeText, grey)
        TextRect.center = (display_width * .5, 80)
        gameDisplay.blit(TextSurf, TextRect)

        actionscreenbuttons = []
        x = 1
        xinc = display_width/5
        yinc = display_height * .5
        while x < 7:
            hitbutton = Button(xinc, yinc, 100, 50, str(x), x)
            actionscreenbuttons.append(hitbutton)
            x += 1
            xinc += 150
            if x == 4:
                yinc += 100
                xinc = display_width/5


        for button in actionscreenbuttons:
            button.print()
        pygame.display.flip()

        actionscreen = True
        while actionscreen:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            for button in actionscreenbuttons:
                Mouse_x, Mouse_y = pygame.mouse.get_pos()
                if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
                    if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                        click = pygame.mouse.get_pressed()
                        if click != (0, 0, 0):

                            self.numberofplayers = button.value + 1
                            actionscreen = False
                            time.sleep(1 / gamespeed)


    def simulationscreen(self):

        global simulation

        gameDisplay.fill(black)

        largeText = pygame.font.Font('freesansbold.ttf', 50)
        TextSurf, TextRect = text_objects('Simulation ?', largeText, grey)
        TextRect.center = (display_width * .5, 80)
        gameDisplay.blit(TextSurf, TextRect)

        actionscreenbuttons = []

        hitbutton = Button(display_width/2.5, display_height/2, 100, 50, 'YES', True)
        actionscreenbuttons.append(hitbutton)

        hitbutton = Button(display_width/2.5, display_height/2 + 100, 100, 50, 'NO', False)
        actionscreenbuttons.append(hitbutton)

        for button in actionscreenbuttons:
            button.print()
        pygame.display.flip()

        actionscreen = True
        while actionscreen:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            for button in actionscreenbuttons:
                Mouse_x, Mouse_y = pygame.mouse.get_pos()
                if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
                    if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                        click = pygame.mouse.get_pressed()
                        if click != (0, 0, 0):

                            simulation = button.value
                            actionscreen = False
                            time.sleep(.5)


    def musicscreen(self):



        gameDisplay.fill(black)

        largeText = pygame.font.Font('freesansbold.ttf', 50)
        TextSurf, TextRect = text_objects('Would you like Music ?', largeText, grey)
        TextRect.center = (display_width * .5, 80)
        gameDisplay.blit(TextSurf, TextRect)

        actionscreenbuttons = []

        hitbutton = Button(display_width/2.5, display_height/2, 100, 50, 'YES', True)
        actionscreenbuttons.append(hitbutton)

        hitbutton = Button(display_width/2.5, display_height/2 + 100, 100, 50, 'NO', False)
        actionscreenbuttons.append(hitbutton)

        for button in actionscreenbuttons:
            button.print()
        pygame.display.flip()

        musicscreen = True
        while musicscreen:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            for button in actionscreenbuttons:
                Mouse_x, Mouse_y = pygame.mouse.get_pos()
                if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
                    if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                        click = pygame.mouse.get_pressed()
                        if click != (0, 0, 0):

                            self.music = button.value
                            musicscreen = False
                            time.sleep(.5)


    def strategyscreen(self):



        gameDisplay.fill(black)

        largeText = pygame.font.Font('freesansbold.ttf', 50)
        TextSurf, TextRect = text_objects('Which betting strategy ?', largeText, grey)
        TextRect.center = (display_width * .5, 80)
        gameDisplay.blit(TextSurf, TextRect)

        actionscreenbuttons = []

        hitbutton = Button(display_width/2.5 - 50, display_height/2, 250, 50, 'MIT Strategy (21 Movie)', "MIT Strategy")
        actionscreenbuttons.append(hitbutton)

        hitbutton = Button(display_width/2.5 - 50, display_height/2 + 100, 250, 50, 'Blackjack Trainer Strategy', "Blackjack Trainer Strategy")
        actionscreenbuttons.append(hitbutton)

        for button in actionscreenbuttons:
            button.print()
        pygame.display.flip()

        musicscreen = True
        while musicscreen:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()

            for button in actionscreenbuttons:
                Mouse_x, Mouse_y = pygame.mouse.get_pos()
                if Mouse_x >= button.left and Mouse_x <= button.left + button.length:
                    if Mouse_y >= button.top and Mouse_y <= button.top + button.width:
                        click = pygame.mouse.get_pressed()
                        if click != (0, 0, 0):

                            self.betStrategy = button.value
                            for player in self.players:
                                player.betStrategy = self.betStrategy
                            musicscreen = False
                            time.sleep(.5)


    def playintro(self):
        vid = Video(os.path.join('videos', 'blackjacksimintrovid.mp4'))

        #uncomment this block if you need to run the resizer - just run it once
        #to generate the resized video, then point to that resized video in your
        #vid.draw statement, comment code back out when done resizing

        #start of resizer code#
#        vidpath = os.path.join('videos', 'blackjacksimintrovid.mp4')
#        import moviepy.editor as mp
#        clip = mp.VideoFileClip(vidpath)
#        clip_resized = clip.resize(newsize=(display_width,display_height))
#        clip_resized.write_videofile("movie_resized.mp4")
        ##end of resizer code#

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        clock = pygame.time.Clock()
        win = gameDisplay

        t_end = time.time() + 6
        while time.time() < t_end:
            clock.tick(60)
            vid.draw(win, (0, 0), force_draw=False)
            pygame.display.update()

table = Table()